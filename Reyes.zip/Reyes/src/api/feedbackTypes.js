export const STOP_FEEDBACK = 'STOP_FEEDBACK';
export const START_FEEDBACK = 'START_FEEDBACK';
export const LOADING_STARTS = 'LOADING_STARTS';
export const LOADING_STOPS = 'LOADING_STOPS';
export const GET_LIST = 'GET_LIST';

